ZHSI (Zibo737 Glass Cockpit Software Suite) by Andre Els (https://www.facebook.com/sum1els737)

ZHSI is a Glass Cockpit Software suite for ZiboMod 737 inspired by XHSI (credit to those guys !!)

Overview:
---------

ZHSI does not use it's own plugin, but instead rely on the ExtPlane plugin, so please make sure you have that installed before running ZHSI. It can be downloaded here (https://github.com/vranki/ExtPlane/releases/download/1.0/extplane.zip)

ZHSI generates it's own DB files (airpots/runways) from the default apt.dat file in XPlane (located in : /Resources/default scenery/default apt dat/Earth nav data/apt.dat).

Plugin Installation:
--------------------

As mentioned, ZHSI uses the ExtPlane plugin, as of writing, the current version is v1. The plugin is also available for download here: (https://forums.x-plane.org/index.php?/files/file/45136-zhsi-zibo737-glass-cockpit-software-suite/)
It includes the MAC and Windows plugin, please copy the "extplane" folder to your XPlane Resources/plugins directory.

You can always check for the latest plugin from the author(s) themselves : https://github.com/vranki/ExtPlane (thanks to Ville Ranki).

How to use ZHSI:
----------------

After launcing ZHSI for the first time, please update the XPlane directory/folder under the Settings page, then restart ZHSI, this will then generate the DB files mentioned above (might take slightly longer to start while generating these files). It should then generate two files called zhsi_apt.dat and zhsi_rwy.dat. This file generation only happens once. If for any reason you believe the apt.dat file in XPlane has been updated since you generated the files, just delete the DB files (zhsi_apt.dat and zhsi_rwy.dat) and restart ZHSI, it will then generate them again.

Also, update the IP address of the XPlane machine in the Settings tab, so that it can connect to the ExtPlane plugin. If running on the same machine, you can leave it as default 127.0.0.1, if not, change to the correct IP address and make sure any firewalls allow TCP port 51000.

ZHSI has 5 displays, Captain Outboard, Captain Inboard, FO Outboard, FO Inboard, Upper EICAS (aka Engine) and Lower EICAS (aka MFD). These can be enabled and disabled in the Displays tab.

You can move any of these displays around the screen, resize them using the scroll wheel on your mouse OR Left and Right Arrow, if needed, when you are happy with the size and location, you can save it by "right clicking" and choose "Save DU Size and Location". This will save the data in the properties file (ZHSI.properties) for future launches.

TERRAIN Display Configuration: 
-----------------------------

In order for the Terrain Radar to work, you need to download a copy of all the Elevation tiles from (https://www.ngdc.noaa.gov/mgg/topo/gltiles.html). Direct download link if needed : (https://www.ngdc.noaa.gov/mgg/topo/DATATILES/elev/all10g.zip)

Once extracted, it will or should create a directory called "all10" with 17 files inside, named from a10g to p10g. In ZHSI (settings tab, called EGPWS directory), you need to browse and SELECT this "all10" folder (or whatever you called it), as ZHSI will then check if the 17 files exist within, if so, it will save the settings. The name should also turn Green if saved successfully. Restart ZHSI to generate the data and Terrain should then be working.

PLEASE DO NOT compare the Terrain radar to the existing Terrain plugin that exists for Zibo737. We use completely different data sources and possibly different logic as well. I use the following logic as found in the 737 FCOM:

• Dotted red: Terrain more than 2,000 feet above airplane’s current altitude
• Dotted amber: Terrain 500 feet (250 feet with gear down) below to 2,000 feet above the airplane’s current altitude
• Dotted green: Terrain from 2,000 feet below to 500 feet (250 feet with gear down) below the airplane’s current altitude
• Black: No significant terrain
• Terrain more than 2,000 feet below airplane altitude or within 200 feet of nearest airport runway elevation does not show.

Weather Radar Configuration:
----------------------------

I only have XP11, so not sure if this is different for older versions, but in order ZHSI to receive weather from X-Plane, you have to do the following (in X-Plane):

• Go Settings -> Network -> click on iPHONE, iPAD and EXTERNAL APPS
• Check the box that says "Use Control Pad as an IOS"
• In the IP Address field, type in the IP address of the PC that runs ZHSI, if on the same machine, you can use 127.0.0.1
• Click on Done

ZHSI, Weather status should change to green


Report bugs/improvements/suggestions:
-------------------------------------

Please report any bugs, improvements and/or suggestions over at bitbucket : https://bitbucket.org/sum1els737/zhsi/issues
It's the only way to avoid duplicates (please check if issue has been reported before) and for me to keep track of all issues and address them when I have time.


Known Issues:
-------------

Please see/report issues on the current issues list : https://bitbucket.org/sum1els737/zhsi/issues


Patreon Support:
----------------

Please consider supporting me on Patreon if you wish, anything appreciated (https://www.patreon.com/sum1els737)


Changelog:
----------

v1.17.1 (bugfix):
-----------------

#162	Fixed: Fix rings sometimes not shown, due to incorrect apt.dat parsing resulting in no lat/lon data for some airports.

v1.17.0:
--------


#143	Fixed: Tuned VOR was not displayed correctly in PLN mode.
#146	Added: Position trend vector (turn) added to ND. Might need fine tuning
#157	Fixed: Hopefully this issue is now fixed (Lat deviation in PFD)
#158	Added: Fuel Flow used indication on Upper EICAS
#161	Fixed: Flap position in newer Zibo versions
#163	Added: CWS-R and CWS-P annunciations
#166	Added: Glideslope deviation to ND (APP mode)
#164	Fixed: Flightplan not shown right after loading .FMS flightplan

Other Changes:
--------------
Added: New feature - Captain + FO Chronos
Corrected spacing between 5/10 degree marks for the compass (PFD)
Terrain Display should no longer show water (oceans)

v1.16.0:
--------

#18		Added: New feature, ISFD Instrument Added (Chronos to follow)
#149	Fixed: Lateral Deviation was inverted
#144	Fixed: LNAV path deviation superimposed with ILS localizer deviation
#153	Added: Option to enable UI to be minimized on startup
#151	Tweaked: Memory issue not allowing all panels to be displayed has been tweaked, but have a look at issue #151 for more details
#156	Fixed: PFD altitude to show a "negative" sign for altitudes below 0

v1.15.1 (Bugfix):

#145	Fixed: DU displays does not turn off or start in Cold and Dark state.

Other: new versioning format (Major.Minor.Revision)

v0.0.1o:

#105	Added: CDU Fixes with distance rings (not completed Radials yet)
#106	Added: VNAV path deviation to ND/PFD
#111	Improved: When selecting direct to Waypoint, path aligns with plane.
#112	Fixed: Runway display as part of flight plan fixed. (part of #101)
#113	Changed: Altitude Restrictions added to Waypionts (no ETA yet)
#115	Fixed: MCP heading bug does not disappear with line anymore
#117	Added: N1 Command Sectors
#118	Added: Compact Engine Display (enabled under Options)
#121	Added: TAI indications on Engine display
#126	Improved: Old waypoints disappear from display. Needs more testing ?
#135	Fixed: Flight plan/route should disappear after landing ? Needs more testing ?
#139	Added: Hardware throttle position indicators in Engine display (enabled under Options)
#140	Added: Landing Altitude added to PFD (Amber hashed area on Alt tape)
#141	Fixed: VS bug only shows when V/S mode is selected
#142	Added: Stand-Alone DMEs now shown

Other improvements/additions:
- ZHSI now requires registation (it's FREE, but please consider supporting me on Patreon (https://www.patreon.com/sum1els737) :) It is mainly to track for commercial use. Please see the "Register" link under the Help menu for more details.
- Under Settings, I have added two sliders, Alt and IAS smoothness factor. This is to fine tune the smoothness of the Alt and Speed readouts (as this depends on your screen resolution, etc ..) It can be adjusted while in flight as desired.


v0.0.1n: (FMC route curved lines removed for now)

#89		Fixed: Hopefully this isssue is fixed with tweaked FMC route.
#96		Added: REV anninciators for reverses (upper EICAS)
#98		Fixed: First leg not shown, should be fixed if departing runway is not selected
#99		Tweaked: TC/TD/DECEL locations
#101	Fixed: Runways not showing in FMC route. Should be showing up now.
#104	Added: Hold patterns, experimental, not fully tested

v0.0.1m: New UI and separate app packages for Windows/Mac

#23		Added: TC/TD/DECEL waypoints to the ND
#30		Added: Pull UP and Windshear alerts to PFD
#35		Added: Metric Selected Altitude box/indication
#78		Added: VREF speeds to PFD
#90		Added: SINGLE CH and LAND 3 annunicators to PFD
#93		Added: X-RAAS support (display on ND). Can be disabled in Options Menu
				Needs X-RAAS plugin installed !

v.0.0.1l: OpenGL Libraries no longer needed !!

#9		Added: Weather radar, please see instructions above how to configure (more tweaking needed)
#12		Fixed: WPT (Waypoint) display on ND
#44		Added: APP/VOR and APP CTR/VOR CTR/MAP CTR modes added to ND
#57		Added: Flightplan step in PLN mode should now work
#67		Fixed: ZHSI should now try to reconnect when X-Plane closes
#66		Changed: VOR frequencies now show if station is not picked up
#85		Fixed: Magnetic variation to VOR stations should now be fixed to correspond to Zibo
#86		Fixed: Dots (period) looked like Commas on some machines, should no be fixed.
#87		Fixed: Commanded throttle position marker for both engines should now work.
#88		Fixed: since zibo 3.29+ the flap gauge was broken, should now be fixed.

Others:
		Tweaked Terrain Display


v.0.0.1k_a:
Tweaked ILS Localizer/Glideslope reception display on PFD.

v0.0.1k:
#77		Added: Added rough distance to nearest airport in Dashboard

Other Additions:
		Added: Terrain Radar functionality. Please see above for installation

v0.0.1j:
#76		Fixed: Bug fixed due to array out of bounds.

v0.0.1i:
#75		Fixed: Fixed a Major bug in ND code preventing it from displayed!

v0.0.1h:
#74		Fixed: Fuel flow now shows in LBS when switching units.
#53		Added: Range Rings (Arcs) have now been added as part of the TCAS system.
#8		Added: TCAS has been added.

Other Additions:
		Some work in flightplan logic :
			Added: Modified route
			Added: Runway center line
			Added: Route is now more curved

v0.0.1g:
#50		Fixed: More than one connection does not receieve initial values (plugin issue).
#49		Added: Fuel can now be displayed in KG or LBS (selectable in Settings tab)
#27		Fixed: Improved Fuel Quantity Alerting Logic (LOW, CONFIG and IMBAL).
Other Additions :
		Displays can now also be resized with LEFT and RIGHT arrow keys if needed.

v0.0.1f:
#6		Added: VOR/ADF arrows to ND
#71		Fixed: ANP/RNP backgrounds
#72		Fixed: AoA was green, should be white.
#70		Changed: To exit, can now click on "X". Also removed Confirmation dialog.
Other Additions :
#51		Added VOR ND Screen
		Added Flap Gauge, selectable via "Displays" tab


v0.0.1e:
#55		Fix: ND doesn't show when XP directory not set
#58		Fix: MAC plugin compiled / crash issue fixed
#52		Change: Lower DU now shows Engines by default from cold and dark
#3		Added: Max/Min Speed bars + Min/Max Maneuver Speed bars
#32		Added: Green Speed Trend Vector
#59		Fix: Alt Alert box to only show when airborne
#65		Added: Flaps Maneuvering Speed readouts
#54		Added: Green Altitude Range arc to ND
#24		Added: FMC Source and ANP/RNP to ND
#68		Added: Added 80 and V2+15 speed bugs

General: 	UI updated, so you can now browse to the X-Plane executable, instead of copy and paste folder.

v0.0.1d:
#13 	Added new UI, which includes options to change/disable/enable features
#46 	Fixed VOR Radials (course line) to include magnetic variation
#40 	Tweaked MFD SYS/ENG button logic.

v0.0.1c:
#34 	Added Stab Trim indicator to Upper EICAS display, will have option in future to disable in settings
#26 	Added ALT Callout box (White)
#11 	Added MFD SYS display page

v0.0.1b:
#22 	Fixed fuel flow display on MFD to show on N2 rotation
#21 	Fixed NO VSPD logic, should disappear when VR is set or when off the ground
#7  	Added Active Waypoint information in upper right corner of ND display
#2  	Added Magenta flight director bars to ADI
#20 	Fixed DME format for ILS display (was too long)
#4  	Fixed N1 manual mode selector display
#19 	Fixed Magenta heading bug not rotating when LNAV is set
#5  	Added Groundspeed, Wind Speed and Direction to upper left corner of ND display
#28 	Added Localizer and Glideslope deviation markers to PFD, but need some more testing.


v0.0.1a:
initial "Alpha" release
Still contains lots of missing features/bugs.